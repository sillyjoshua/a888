// Token bucket: each key gets `rps` tokens per second, with a burst of up to 2x rps.
// In-memory and per-process, which is right for a single self-hosted instance.
// (If you run several instances behind a load balancer, limits apply per instance.)

export class RateLimiter {
  constructor(now = () => Date.now()) {
    this.now = now;
    this.buckets = new Map();
    this.sweeper = setInterval(() => this.sweep(), 60_000);
    this.sweeper.unref();
  }

  // Returns { ok, retryAfter } where retryAfter is in whole seconds.
  take(id, rps) {
    const t = this.now();
    const burst = rps * 2;
    let b = this.buckets.get(id);
    if (!b) {
      b = { tokens: burst, last: t };
      this.buckets.set(id, b);
    }
    b.tokens = Math.min(burst, b.tokens + ((t - b.last) / 1000) * rps);
    b.last = t;
    if (b.tokens >= 1) {
      b.tokens -= 1;
      return { ok: true, retryAfter: 0 };
    }
    return { ok: false, retryAfter: Math.max(1, Math.ceil((1 - b.tokens) / rps)) };
  }

  // Drop buckets idle long enough to have fully refilled anyway.
  sweep() {
    const t = this.now();
    for (const [id, b] of this.buckets) if (t - b.last > 120_000) this.buckets.delete(id);
  }

  stop() {
    clearInterval(this.sweeper);
  }
}

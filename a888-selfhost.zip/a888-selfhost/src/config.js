import fs from "node:fs";

// All configuration comes from environment variables so it works the same on
// Render, Fly, Railway, Docker, or a bare VPS.
//
//   PORT          listen port                      (default 8888)
//   DB_PATH       SQLite file                      (default ./data/a888.db)
//   ADMIN_TOKEN   enables admin API + web UI       (required for those)
//   UPSTREAM      single upstream base URL         (simple setups)
//   UPSTREAMS     JSON file mapping routes         (multiple upstreams)
//   TRUST_PROXY   "1" to trust X-Forwarded-For     (default off)
//
// UPSTREAMS file format:
//   { "routes": [
//       { "prefix": "/weather", "target": "https://weather.internal", "strip": true },
//       { "prefix": "/",        "target": "https://api.example.com" }
//   ] }

export const PLANS = {
  starter: { quota: 100_000, rps: 10 },
  pro: { quota: 2_000_000, rps: 50 },
  team: { quota: 20_000_000, rps: 200 },
};

export function loadConfig(env = process.env) {
  const routes = [];

  if (env.UPSTREAMS) {
    const parsed = JSON.parse(fs.readFileSync(env.UPSTREAMS, "utf8"));
    for (const r of parsed.routes ?? []) {
      if (!r.prefix?.startsWith("/")) throw new Error(`route prefix "${r.prefix}" must start with /`);
      new URL(r.target); // throws on a bad URL
      routes.push({ prefix: r.prefix, target: r.target, strip: !!r.strip });
    }
  } else if (env.UPSTREAM) {
    new URL(env.UPSTREAM);
    routes.push({ prefix: "/", target: env.UPSTREAM, strip: false });
  }

  // Longest prefix wins, so "/weather/v2" beats "/weather" beats "/".
  routes.sort((a, b) => b.prefix.length - a.prefix.length);

  const port = Number(env.PORT ?? 8888);
  if (!Number.isInteger(port) || port < 0 || port > 65535) throw new Error("PORT must be 0-65535");

  return {
    port,
    dbPath: env.DB_PATH ?? "./data/a888.db",
    adminToken: env.ADMIN_TOKEN ?? "",
    routes,
    trustProxy: env.TRUST_PROXY === "1",
  };
}

export function matchRoute(routes, pathname) {
  for (const r of routes) {
    if (r.prefix === "/") return r;
    if (pathname === r.prefix || pathname.startsWith(r.prefix.endsWith("/") ? r.prefix : r.prefix + "/")) return r;
  }
  return null;
}

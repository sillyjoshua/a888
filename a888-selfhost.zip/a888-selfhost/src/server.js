import http from "node:http";
import https from "node:https";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { extractKey, looksLikeKey, hashKey, safeEqual } from "./keys.js";
import { matchRoute } from "./config.js";
import { Store, UserError } from "./store.js";
import { RateLimiter } from "./ratelimit.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(__dirname, "..", "public");

// Headers that must not be forwarded between hops (RFC 9110 section 7.6.1).
const HOP_BY_HOP = new Set(["connection", "keep-alive", "proxy-authenticate", "proxy-authorization", "te", "trailer", "transfer-encoding", "upgrade", "proxy-connection"]);

const ADMIN_PREFIX = "/_a888";
const MAX_ADMIN_BODY = 64 * 1024;

function sendJson(res, status, body, headers = {}) {
  const data = JSON.stringify(body);
  res.writeHead(status, { "content-type": "application/json; charset=utf-8", "content-length": Buffer.byteLength(data), ...headers });
  res.end(data);
}

function sendError(res, status, code, message, headers = {}) {
  sendJson(res, status, { error: { code, message } }, headers);
}

function readJson(req, limit = MAX_ADMIN_BODY) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on("data", (c) => {
      size += c.length;
      if (size > limit) {
        reject(new UserError("request body too large", 413));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on("end", () => {
      if (chunks.length === 0) return resolve({});
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString("utf8")));
      } catch {
        reject(new UserError("body must be valid JSON"));
      }
    });
    req.on("error", reject);
  });
}

export function createServer(config, { store = new Store(config.dbPath), limiter = new RateLimiter() } = {}) {
  const adminEnabled = config.adminToken.length >= 16;

  async function handleAdmin(req, res, url) {
    if (!adminEnabled) return sendError(res, 404, "not_found", "Admin is disabled. Set ADMIN_TOKEN (16+ characters) to enable it.");

    // The UI shell is public (it holds no data); every /api call needs the token.
    const sub = url.pathname.slice(ADMIN_PREFIX.length) || "/";
    if (req.method === "GET" && (sub === "/" || sub === "/index.html")) return serveStatic(res, "index.html", "text/html; charset=utf-8");

    if (!sub.startsWith("/api/")) return sendError(res, 404, "not_found", "Not found.");

    const auth = req.headers["authorization"] ?? "";
    const m = auth.match(/^Bearer\s+(\S+)$/i);
    if (!m || !safeEqual(m[1], config.adminToken)) {
      return sendError(res, 401, "unauthorized", "Invalid admin token.", { "www-authenticate": 'Bearer realm="a888-admin"' });
    }

    try {
      const route = `${req.method} ${sub}`;
      if (route === "GET /api/keys") return sendJson(res, 200, { keys: store.list({ status: url.searchParams.get("status") || undefined }) });
      if (route === "GET /api/plans") return sendJson(res, 200, { plans: (await import("./config.js")).PLANS });
      if (route === "POST /api/keys") {
        const b = await readJson(req);
        return sendJson(res, 201, store.create({ email: b.email, plan: b.plan, days: b.days ?? 30, quota: b.quota, rps: b.rps, paths: b.paths ?? [], note: b.note ?? "" }));
      }
      const m2 = sub.match(/^\/api\/keys\/([^/]+)\/(renew|suspend|resume|revoke)$/);
      if (m2 && req.method === "POST") {
        const [, id, action] = m2;
        if (action === "renew") {
          const b = await readJson(req);
          return sendJson(res, 200, store.renew(id, b.days ?? 30));
        }
        const status = { suspend: "suspended", resume: "active", revoke: "revoked" }[action];
        return sendJson(res, 200, store.setStatus(id, status));
      }
      const m3 = sub.match(/^\/api\/keys\/([^/]+)$/);
      if (m3 && req.method === "GET") {
        const r = store.find(m3[1]);
        return sendJson(res, 200, { ...store.publicView(r), used: store.usedThisMonth(r.hash) });
      }
      return sendError(res, 404, "not_found", "Unknown admin endpoint.");
    } catch (err) {
      if (err instanceof UserError) return sendError(res, err.status, "bad_request", err.message);
      console.error("admin error:", err);
      return sendError(res, 500, "internal_error", "Internal error.");
    }
  }

  function serveStatic(res, file, type) {
    fs.readFile(path.join(PUBLIC_DIR, file), (err, data) => {
      if (err) return sendError(res, 500, "internal_error", "UI file missing.");
      res.writeHead(200, {
        "content-type": type,
        "content-length": data.length,
        "cache-control": "no-store",
        // The admin page loads nothing external and talks only to this origin.
        "content-security-policy": "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; img-src data:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
        "x-content-type-options": "nosniff",
        "referrer-policy": "no-referrer",
      });
      res.end(data);
    });
  }

  function handleProxy(req, res, url) {
    const key = extractKey(req.headers);
    if (!key) return sendError(res, 401, "missing_key", "Provide your key via 'Authorization: Bearer <key>' or 'X-API-Key'.", { "www-authenticate": 'Bearer realm="a888"' });
    if (!looksLikeKey(key)) return sendError(res, 401, "invalid_key", "Invalid API key.");

    const hash = hashKey(key);
    const rec = store.getByHash(hash);
    if (!rec) return sendError(res, 401, "invalid_key", "Invalid API key.");
    if (rec.status === "revoked") return sendError(res, 401, "revoked_key", "This key has been revoked.");
    if (rec.status === "suspended") return sendError(res, 402, "payment_required", "Key suspended. Contact billing to renew.");
    if (rec.expires_at && Date.parse(rec.expires_at) <= Date.now()) return sendError(res, 402, "expired", "Key expired. Contact billing to renew.");

    if (rec.allowed_paths.length > 0 && !rec.allowed_paths.some((p) => url.pathname.startsWith(p))) {
      return sendError(res, 403, "path_not_allowed", "This key is not allowed to access that path.");
    }

    const route = matchRoute(config.routes, url.pathname);
    if (!route) return sendError(res, 502, "no_upstream", "No upstream is configured for this path.");

    // Rate limit before spending quota, so throttled requests don't burn the monthly allowance.
    const rl = limiter.take(hash, rec.rps);
    if (!rl.ok) return sendError(res, 429, "rate_limited", "Too many requests. Slow down.", { "retry-after": String(rl.retryAfter) });

    const c = store.consume(hash, rec.quota);
    const quotaHeaders = { "x-a888-quota": String(rec.quota), "x-a888-used": String(c.used), "x-a888-remaining": String(Math.max(0, rec.quota - c.used)) };
    if (!c.ok) return sendError(res, 429, "quota_exceeded", "Monthly request quota reached. Contact billing to upgrade.", quotaHeaders);

    // Build the upstream request.
    let upstreamPath = url.pathname;
    if (route.strip && route.prefix !== "/") upstreamPath = url.pathname.slice(route.prefix.length) || "/";
    const base = new URL(route.target);
    const basePath = base.pathname.replace(/\/$/, "");
    const target = new URL(basePath + upstreamPath + url.search, base.origin);

    const headers = {};
    for (const [k, v] of Object.entries(req.headers)) {
      if (HOP_BY_HOP.has(k) || k === "authorization" || k === "x-api-key" || k === "cookie" || k === "host") continue;
      headers[k] = v;
    }
    headers["x-a888-plan"] = rec.plan;
    const ip = req.socket.remoteAddress ?? "";
    const fwd = config.trustProxy && req.headers["x-forwarded-for"] ? `${req.headers["x-forwarded-for"]}` : ip;
    headers["x-forwarded-for"] = fwd;

    const lib = target.protocol === "https:" ? https : http;
    const upstream = lib.request(
      { protocol: target.protocol, hostname: target.hostname, port: target.port || undefined, path: target.pathname + target.search, method: req.method, headers: { ...headers, host: target.host }, timeout: 30_000 },
      (up) => {
        const out = {};
        for (const [k, v] of Object.entries(up.headers)) if (!HOP_BY_HOP.has(k)) out[k] = v;
        Object.assign(out, quotaHeaders);
        res.writeHead(up.statusCode ?? 502, out);
        up.pipe(res);
      }
    );
    upstream.on("timeout", () => upstream.destroy(new Error("timeout")));
    upstream.on("error", () => {
      if (!res.headersSent) sendError(res, 502, "upstream_unreachable", "The upstream API could not be reached.", quotaHeaders);
      else res.destroy();
    });
    // If the client disconnects, stop the upstream call.
    res.on("close", () => {
      if (!res.writableEnded) upstream.destroy();
    });
    req.pipe(upstream);
  }

  const server = http.createServer((req, res) => {
    let url;
    try {
      url = new URL(req.url ?? "/", "http://placeholder");
    } catch {
      return sendError(res, 400, "bad_request", "Malformed URL.");
    }

    if (url.pathname === "/health") return sendJson(res, 200, { status: "ok", service: "a888", time: new Date().toISOString() });
    if (url.pathname === ADMIN_PREFIX || url.pathname.startsWith(ADMIN_PREFIX + "/")) {
      handleAdmin(req, res, url).catch((err) => {
        console.error(err);
        if (!res.headersSent) sendError(res, 500, "internal_error", "Internal error.");
      });
      return;
    }
    if (req.method === "OPTIONS") {
      res.writeHead(204, {
        "access-control-allow-origin": "*",
        "access-control-allow-headers": "authorization, x-api-key, content-type",
        "access-control-allow-methods": "GET, POST, PUT, PATCH, DELETE, OPTIONS",
        "access-control-max-age": "86400",
      });
      return res.end();
    }
    handleProxy(req, res, url);
  });

  server.on("close", () => {
    limiter.stop();
    store.close();
  });
  server.store = store;
  return server;
}

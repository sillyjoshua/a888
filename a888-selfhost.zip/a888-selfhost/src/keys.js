import crypto from "node:crypto";

export const KEY_PREFIX = "a888_live_";

// Crockford-style alphabet: no i, l, o, u so keys survive being read aloud or retyped.
const ALPHABET = "0123456789abcdefghjkmnpqrstvwxyz";

export function generateKey() {
  const bytes = crypto.randomBytes(24); // 192 bits
  let out = "";
  for (const b of bytes) out += ALPHABET[b % 32];
  return KEY_PREFIX + out;
}

export function hashKey(key) {
  return crypto.createHash("sha256").update(key).digest("hex");
}

export function looksLikeKey(value) {
  return typeof value === "string" && value.startsWith(KEY_PREFIX) && value.length >= KEY_PREFIX.length + 20 && value.length <= 128;
}

export function extractKey(headers) {
  const auth = headers["authorization"];
  if (typeof auth === "string") {
    const m = auth.match(/^Bearer\s+(\S+)$/i);
    if (m) return m[1];
  }
  const x = headers["x-api-key"];
  if (typeof x === "string" && x.trim()) return x.trim();
  return null;
}

// Constant-time comparison for the admin token.
export function safeEqual(a, b) {
  const ab = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (ab.length !== bb.length) return false;
  return crypto.timingSafeEqual(ab, bb);
}

export function monthBucket(date = new Date()) {
  return date.toISOString().slice(0, 7);
}

import { loadConfig } from "./config.js";
import { createServer } from "./server.js";

const config = loadConfig();
const server = createServer(config);

server.listen(config.port, () => {
  const routes = config.routes.length ? config.routes.map((r) => `${r.prefix} -> ${r.target}`).join(", ") : "none (set UPSTREAM or UPSTREAMS)";
  console.log(`a888 listening on :${config.port}`);
  console.log(`  upstreams: ${routes}`);
  console.log(`  admin:     ${config.adminToken.length >= 16 ? "enabled at /_a888/" : "disabled (set ADMIN_TOKEN, 16+ chars)"}`);
  console.log(`  database:  ${config.dbPath}`);
});

function shutdown() {
  console.log("shutting down");
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 5000).unref();
}
process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);

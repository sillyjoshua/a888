import { DatabaseSync } from "node:sqlite";
import fs from "node:fs";
import path from "node:path";
import { generateKey, hashKey, monthBucket } from "./keys.js";
import { PLANS } from "./config.js";

const DAY = 86_400_000;

const SCHEMA = `
CREATE TABLE IF NOT EXISTS keys (
  hash          TEXT PRIMARY KEY,
  email         TEXT NOT NULL,
  plan          TEXT NOT NULL,
  quota         INTEGER NOT NULL,
  rps           INTEGER NOT NULL,
  status        TEXT NOT NULL DEFAULT 'active',
  allowed_paths TEXT NOT NULL DEFAULT '[]',
  note          TEXT NOT NULL DEFAULT '',
  created_at    TEXT NOT NULL,
  expires_at    TEXT,
  updated_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS keys_email ON keys(email);

CREATE TABLE IF NOT EXISTS usage (
  hash   TEXT NOT NULL,
  bucket TEXT NOT NULL,
  count  INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (hash, bucket)
);
`;

export class Store {
  constructor(file = ":memory:") {
    if (file !== ":memory:") fs.mkdirSync(path.dirname(path.resolve(file)), { recursive: true });
    this.db = new DatabaseSync(file);
    this.db.exec("PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000;");
    this.db.exec(SCHEMA);

    this._getKey = this.db.prepare("SELECT * FROM keys WHERE hash = ?");
    // Atomic: increments only while under quota. Returns the row if it counted, nothing if the quota was hit.
    this._bump = this.db.prepare(`
      INSERT INTO usage (hash, bucket, count) VALUES (?, ?, 1)
      ON CONFLICT(hash, bucket) DO UPDATE SET count = count + 1
      WHERE count < ?
      RETURNING count
    `);
    this._usage = this.db.prepare("SELECT count FROM usage WHERE hash = ? AND bucket = ?");
  }

  close() {
    this.db.close();
  }

  _row(r) {
    if (!r) return null;
    return { ...r, allowed_paths: JSON.parse(r.allowed_paths) };
  }

  create({ email, plan, days = 30, quota, rps, paths = [], note = "" }) {
    if (typeof email !== "string" || !/^[^\s@]+@[^\s@]+$/.test(email)) throw new UserError("valid email required");
    const p = PLANS[plan];
    if (!p) throw new UserError(`plan must be one of: ${Object.keys(PLANS).join(", ")}`);
    if (!(days > 0)) throw new UserError("days must be positive");
    const q = quota ?? p.quota;
    const r = rps ?? p.rps;
    if (!Number.isInteger(q) || q <= 0) throw new UserError("quota must be a positive integer");
    if (!Number.isInteger(r) || r <= 0) throw new UserError("rps must be a positive integer");
    for (const x of paths) if (typeof x !== "string" || !x.startsWith("/")) throw new UserError(`path "${x}" must start with /`);

    const key = generateKey();
    const hash = hashKey(key);
    const now = new Date();
    this.db
      .prepare(
        `INSERT INTO keys (hash,email,plan,quota,rps,status,allowed_paths,note,created_at,expires_at,updated_at)
         VALUES (?,?,?,?,?,'active',?,?,?,?,?)`
      )
      .run(hash, email, plan, q, r, JSON.stringify(paths), String(note), now.toISOString(), new Date(now.getTime() + days * DAY).toISOString(), now.toISOString());
    return { key, ...this.publicView(this._row(this._getKey.get(hash))) };
  }

  getByHash(hash) {
    return this._row(this._getKey.get(hash));
  }

  // Accepts a full key or an id prefix (min 8 chars).
  find(ident) {
    if (typeof ident !== "string" || !ident) throw new UserError("missing key or id");
    if (ident.startsWith("a888_live_")) {
      const r = this.getByHash(hashKey(ident));
      if (!r) throw new UserError("no such key", 404);
      return r;
    }
    if (ident.length < 8) throw new UserError("id prefix must be at least 8 characters");
    if (!/^[0-9a-f]+$/.test(ident)) throw new UserError("id must be hex");
    const rows = this.db.prepare("SELECT * FROM keys WHERE hash LIKE ? || '%' LIMIT 2").all(ident);
    if (rows.length === 0) throw new UserError("no key matches that id", 404);
    if (rows.length > 1) throw new UserError("id is ambiguous; use more characters");
    return this._row(rows[0]);
  }

  list({ status } = {}) {
    const rows = this.db.prepare("SELECT * FROM keys ORDER BY email, created_at").all().map((r) => this._row(r));
    const bucket = monthBucket();
    return rows
      .map((r) => ({ ...this.publicView(r), used: this._usage.get(r.hash, bucket)?.count ?? 0 }))
      .filter((r) => !status || r.status === status);
  }

  renew(ident, days = 30) {
    if (!(days > 0)) throw new UserError("days must be positive");
    const r = this.find(ident);
    if (r.status === "revoked") throw new UserError("revoked keys cannot be renewed; create a new key");
    const base = Math.max(Date.now(), r.expires_at ? Date.parse(r.expires_at) : 0);
    const now = new Date().toISOString();
    this.db.prepare("UPDATE keys SET expires_at = ?, status = 'active', updated_at = ? WHERE hash = ?").run(new Date(base + days * DAY).toISOString(), now, r.hash);
    return this.publicView(this.getByHash(r.hash));
  }

  setStatus(ident, status) {
    const r = this.find(ident);
    if (r.status === "revoked" && status !== "revoked") throw new UserError("revoked keys cannot be restored; create a new key");
    this.db.prepare("UPDATE keys SET status = ?, updated_at = ? WHERE hash = ?").run(status, new Date().toISOString(), r.hash);
    return this.publicView(this.getByHash(r.hash));
  }

  // Count one request unless the monthly quota is already used up. Exact under concurrency.
  consume(hash, quota) {
    const bucket = monthBucket();
    const row = this._bump.get(hash, bucket, quota);
    if (row) return { ok: true, used: row.count };
    return { ok: false, used: this._usage.get(hash, bucket)?.count ?? quota };
  }

  usedThisMonth(hash) {
    return this._usage.get(hash, monthBucket())?.count ?? 0;
  }

  // Never expose the full hash; the 12-char id is enough to reference a key.
  publicView(r) {
    const expired = r.expires_at && Date.parse(r.expires_at) <= Date.now();
    return {
      id: r.hash.slice(0, 12),
      email: r.email,
      plan: r.plan,
      quota: r.quota,
      rps: r.rps,
      status: r.status === "active" && expired ? "expired" : r.status,
      allowed_paths: r.allowed_paths,
      note: r.note,
      created_at: r.created_at,
      expires_at: r.expires_at,
    };
  }
}

export class UserError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
}

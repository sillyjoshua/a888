# a888

Free, self-hosted API key gateway. Put keys, quotas and rate limits in front of
any API, on your own server or on Render, Fly, Railway, or any Docker host.

- **No dependencies.** Plain Node 22 with its built-in SQLite. Nothing to `npm install`.
- **Keys you issue by hand.** No signup flow. You create a key, email it, renew it when they pay.
- **Exact quotas, per-key rate limits**, path scoping, expiry, suspend and revoke.
- **Three ways to manage keys:** CLI, admin API, and a simple web page.
- **Keys are stored hashed.** A stolen database file does not reveal usable keys.

```
client --(Bearer a888_live_...)--> a888 --(no credentials)--> your API
                                     |
                                  SQLite
```

## Quick start (Docker)

```bash
git clone <this repo> && cd a888
# edit docker-compose.yml: set UPSTREAM and a long random ADMIN_TOKEN
docker compose up -d
```

Open `http://localhost:8888/_a888/`, sign in with your admin token, create a key, then:

```bash
curl http://localhost:8888/anything -H "Authorization: Bearer a888_live_..."
```

Without Docker: `UPSTREAM=https://your-api.example.com ADMIN_TOKEN=$(openssl rand -hex 24) npm start` (Node 22.5+).

## Deploy to Render

1. Push this repo to GitHub.
2. In Render: **New > Blueprint**, pick the repo. `render.yaml` sets everything up.
3. Enter your `UPSTREAM` when prompted. Render generates `ADMIN_TOKEN` for you (find it under Environment).

Render needs a paid instance for the persistent disk that holds the database.
Fly.io and Railway work the same way: run the Docker image and mount a volume at `/data`.

## Configuration

All settings are environment variables.

| Variable      | Default            | Purpose |
| ------------- | ------------------ | ------- |
| `UPSTREAM`    |                    | The API to protect (simple setup) |
| `UPSTREAMS`   |                    | Path to a JSON file for multiple upstreams (below) |
| `ADMIN_TOKEN` |                    | Enables the admin API and web page. Must be 16+ characters |
| `PORT`        | `8888`             | Listen port |
| `DB_PATH`     | `./data/a888.db`   | SQLite file. Put it on a persistent volume |
| `TRUST_PROXY` | off                | Set `1` when behind a proxy so `X-Forwarded-For` is passed on |

### Multiple upstreams

```json
{
  "routes": [
    { "prefix": "/weather", "target": "https://weather.internal", "strip": true },
    { "prefix": "/",        "target": "https://api.example.com" }
  ]
}
```

Set `UPSTREAMS=/path/to/routes.json`. The longest matching prefix wins. With
`"strip": true`, `/weather/today` reaches the target as `/today`.

## Managing keys

### Web page

`/_a888/` on your server. Create keys, renew, suspend, revoke, and see monthly usage.
The token is held in memory only, so reloading the page signs you out.

### CLI

On the server (reads the database directly):

```bash
node bin/a888.js keys create --email jo@example.com --plan pro --days 30
node bin/a888.js keys create --email sam@example.com --plan starter --paths /v1/,/reports --note "trial"
node bin/a888.js keys list
node bin/a888.js keys renew   <id> --days 30
node bin/a888.js keys suspend <id>
node bin/a888.js keys revoke  <id>
```

From your own machine, against a running server:

```bash
export A888_URL=https://api.yourdomain.com
export ADMIN_TOKEN=...
node bin/a888.js keys list
```

`<id>` is the 12-character id from `keys list` (8 characters is enough), or the full key.

### Admin API

All calls need `Authorization: Bearer $ADMIN_TOKEN`.

| Method & path                       | Body                                                | Action |
| ----------------------------------- | --------------------------------------------------- | ------ |
| `GET /_a888/api/keys?status=`       |                                                     | List keys with usage |
| `POST /_a888/api/keys`              | `{email, plan, days, paths[], quota, rps, note}`    | Create (returns the key once) |
| `GET /_a888/api/keys/:id`           |                                                     | Show one key |
| `POST /_a888/api/keys/:id/renew`    | `{days}`                                            | Extend expiry |
| `POST /_a888/api/keys/:id/suspend`  |                                                     | Block until resumed |
| `POST /_a888/api/keys/:id/resume`   |                                                     | Unblock |
| `POST /_a888/api/keys/:id/revoke`   |                                                     | Permanently disable |
| `GET /_a888/api/plans`              |                                                     | List plans |

## What your customers see

| Status | Meaning |
| ------ | ------- |
| 401 | Missing, invalid, or revoked key |
| 402 | Expired or suspended: renew to continue |
| 403 | Key not allowed to use that path |
| 429 | `rate_limited` (with `Retry-After`) or `quota_exceeded` |
| 502 | Your upstream could not be reached |

Successful responses include `x-a888-quota`, `x-a888-used` and `x-a888-remaining`.
`GET /health` needs no key.

## Plans

Defaults live in `src/config.js`. Change them, or override per key with `--quota` and `--rps`.

| Plan    | Requests / month | Requests / second |
| ------- | ---------------- | ----------------- |
| starter | 100,000          | 10 (burst 20)     |
| pro     | 2,000,000        | 50 (burst 100)    |
| team    | 20,000,000       | 200 (burst 400)   |

## Security notes

- **Use HTTPS.** Keys and the admin token travel in headers. Render, Fly and Railway give you TLS automatically; on a VPS put Caddy or nginx in front.
- **Admin is off unless `ADMIN_TOKEN` is set** (16+ characters). Generate one with `openssl rand -hex 24`. To keep the admin page off the public internet, block `/_a888/` at your proxy.
- **Keys and cookies are stripped** before requests reach your upstream, so your API never sees customer keys.
- **Back up `DB_PATH`.** It is a single SQLite file. Losing it means re-issuing every key.
- **Rate limits are per process.** Fine for one instance; if you scale to several, each enforces its own limit. Quotas are exact because they live in the database.
- **Revoked keys stay revoked.** To give someone access again, issue a new key.

## Tests

```bash
npm test
```

23 tests run a real gateway against a real fake upstream, including exact quota
counting under concurrent load.

## License

MIT. See `LICENSE`.

import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import { createServer } from "../src/server.js";
import { Store } from "../src/store.js";
import { RateLimiter } from "../src/ratelimit.js";
import { loadConfig, matchRoute } from "../src/config.js";
import { generateKey, hashKey, looksLikeKey, extractKey } from "../src/keys.js";

const ADMIN = "test-admin-token-1234567890";

let upstream, upstreamUrl, seen; // what the fake upstream last received
let gw, gwUrl, store;

function listen(server) {
  return new Promise((r) => server.listen(0, "127.0.0.1", () => r(`http://127.0.0.1:${server.address().port}`)));
}

before(async () => {
  upstream = http.createServer((req, res) => {
    const chunks = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", () => {
      seen = { method: req.method, url: req.url, headers: req.headers, body: Buffer.concat(chunks).toString() };
      if (req.url.startsWith("/slow")) return; // never answers (timeout test uses a different path)
      if (req.url.startsWith("/status/418")) {
        res.writeHead(418, { "x-up": "1", "set-cookie": "s=1" });
        return res.end("teapot");
      }
      res.writeHead(200, { "content-type": "application/json" });
      res.end(JSON.stringify({ path: req.url, echo: seen.body }));
    });
  });
  upstreamUrl = await listen(upstream);

  const config = loadConfig({ UPSTREAM: upstreamUrl, ADMIN_TOKEN: ADMIN, PORT: "0" });
  store = new Store(":memory:");
  gw = createServer(config, { store, limiter: new RateLimiter() });
  gwUrl = await listen(gw);
});

after(() => {
  gw.close();
  upstream.close();
});

const call = (path, { key, method = "GET", body, headers = {} } = {}) =>
  fetch(gwUrl + path, { method, body, headers: { ...(key ? { authorization: `Bearer ${key}` } : {}), ...headers } });

const admin = (path, { method = "GET", body, token = ADMIN } = {}) =>
  fetch(gwUrl + "/_a888/api" + path, { method, headers: { authorization: `Bearer ${token}`, "content-type": "application/json" }, body: body ? JSON.stringify(body) : undefined });

const newKey = (over = {}) => store.create({ email: "t@example.com", plan: "starter", ...over });

// ---------- unit-level ----------

test("keys: format, uniqueness, hashing", () => {
  const a = generateKey();
  assert.ok(looksLikeKey(a));
  assert.notEqual(a, generateKey());
  assert.equal(hashKey(a).length, 64);
  assert.ok(!looksLikeKey("nope"));
  assert.equal(extractKey({ authorization: "Bearer abc" }), "abc");
  assert.equal(extractKey({ "x-api-key": "def" }), "def");
  assert.equal(extractKey({}), null);
});

test("config: longest prefix wins and bad input is rejected", () => {
  const routes = [
    { prefix: "/", target: "http://a" },
    { prefix: "/weather", target: "http://b" },
    { prefix: "/weather/v2", target: "http://c" },
  ].sort((x, y) => y.prefix.length - x.prefix.length);
  assert.equal(matchRoute(routes, "/weather/v2/x").target, "http://c");
  assert.equal(matchRoute(routes, "/weather/today").target, "http://b");
  assert.equal(matchRoute(routes, "/weatherman").target, "http://a", "prefix must match on a path boundary");
  assert.throws(() => loadConfig({ UPSTREAM: "not a url" }));
  assert.throws(() => loadConfig({ PORT: "99999" }));
});

test("rate limiter: allows burst then throttles, then refills", () => {
  let t = 0;
  const rl = new RateLimiter(() => t);
  for (let i = 0; i < 4; i++) assert.ok(rl.take("k", 2).ok, "burst of 2x rps");
  const blocked = rl.take("k", 2);
  assert.equal(blocked.ok, false);
  assert.ok(blocked.retryAfter >= 1);
  t += 1000; // 1s refills 2 tokens
  assert.ok(rl.take("k", 2).ok);
  rl.stop();
});

// ---------- gateway ----------

test("/health needs no key", async () => {
  const r = await call("/health");
  assert.equal(r.status, 200);
  assert.equal((await r.json()).status, "ok");
});

test("no key -> 401 with WWW-Authenticate; junk key -> 401", async () => {
  const r = await call("/v1/x");
  assert.equal(r.status, 401);
  assert.ok(r.headers.get("www-authenticate"));
  assert.equal((await r.json()).error.code, "missing_key");
  assert.equal((await call("/v1/x", { key: "garbage" })).status, 401);
  assert.equal((await call("/v1/x", { key: generateKey() })).status, 401);
});

test("valid key proxies; key and cookies never reach upstream", async () => {
  const { key } = newKey();
  const r = await call("/v1/things?x=1", { key, headers: { cookie: "session=secret", "x-custom": "yes" } });
  assert.equal(r.status, 200);
  assert.equal((await r.json()).path, "/v1/things?x=1");
  assert.equal(seen.headers["authorization"], undefined, "key must not leak");
  assert.equal(seen.headers["x-api-key"], undefined);
  assert.equal(seen.headers["cookie"], undefined);
  assert.equal(seen.headers["x-custom"], "yes", "other headers pass through");
  assert.equal(seen.headers["x-a888-plan"], "starter");
  assert.ok(r.headers.get("x-a888-quota"));
});

test("X-API-Key header works too", async () => {
  const { key } = newKey();
  const r = await fetch(gwUrl + "/v1/y", { headers: { "x-api-key": key } });
  assert.equal(r.status, 200);
});

test("POST bodies are forwarded intact", async () => {
  const { key } = newKey();
  const payload = JSON.stringify({ hello: "world", n: [1, 2, 3] });
  const r = await call("/v1/post", { key, method: "POST", body: payload, headers: { "content-type": "application/json" } });
  assert.equal(r.status, 200);
  assert.equal(seen.method, "POST");
  assert.equal(seen.body, payload);
});

test("upstream status codes and headers pass through", async () => {
  const { key } = newKey();
  const r = await call("/status/418", { key });
  assert.equal(r.status, 418);
  assert.equal(r.headers.get("x-up"), "1");
  assert.equal(await r.text(), "teapot");
});

test("quota is exact and over-quota requests never reach upstream", async () => {
  const { key } = newKey({ quota: 3, rps: 100 });
  seen = null;
  for (let i = 0; i < 3; i++) assert.equal((await call("/q", { key })).status, 200);
  seen = null;
  const r = await call("/q", { key });
  assert.equal(r.status, 429);
  assert.equal((await r.json()).error.code, "quota_exceeded");
  assert.equal(r.headers.get("x-a888-remaining"), "0");
  assert.equal(seen, null, "blocked request must not hit upstream");
});

test("quota is exact under concurrent requests", async () => {
  const { key } = newKey({ quota: 10, rps: 1000 });
  const results = await Promise.all(Array.from({ length: 40 }, () => call("/c", { key }).then((r) => r.status)));
  assert.equal(results.filter((s) => s === 200).length, 10, "exactly quota requests succeed");
  assert.equal(results.filter((s) => s === 429).length, 30);
});

test("rate limit returns 429 with Retry-After and does not burn quota", async () => {
  const { key, id } = newKey({ quota: 1000, rps: 1 }); // burst of 2
  const statuses = [];
  for (let i = 0; i < 5; i++) statuses.push((await call("/r", { key })).status);
  assert.equal(statuses.filter((s) => s === 200).length, 2);
  const limited = await call("/r", { key });
  assert.equal(limited.status, 429);
  assert.equal((await limited.json()).error.code, "rate_limited");
  assert.ok(Number(limited.headers.get("retry-after")) >= 1);
  const used = store.usedThisMonth(store.find(id).hash);
  assert.equal(used, 2, "throttled requests must not consume quota");
});

test("expired -> 402, suspended -> 402, revoked -> 401", async () => {
  const exp = newKey();
  store.db.prepare("UPDATE keys SET expires_at = ? WHERE hash = ?").run(new Date(Date.now() - 1000).toISOString(), hashKey(exp.key));
  assert.equal((await call("/a", { key: exp.key })).status, 402);

  const sus = newKey();
  store.setStatus(sus.key, "suspended");
  assert.equal((await call("/a", { key: sus.key })).status, 402);

  const rev = newKey();
  store.setStatus(rev.key, "revoked");
  const r = await call("/a", { key: rev.key });
  assert.equal(r.status, 401);
  assert.equal((await r.json()).error.code, "revoked_key");
});

test("path scoping allows listed prefixes and blocks others", async () => {
  const { key } = newKey({ paths: ["/v1/"] });
  assert.equal((await call("/v1/ok", { key })).status, 200);
  const r = await call("/admin-stuff", { key });
  assert.equal(r.status, 403);
  assert.equal((await r.json()).error.code, "path_not_allowed");
});

test("unreachable upstream -> 502, not a crash", async () => {
  const cfg = loadConfig({ UPSTREAM: "http://127.0.0.1:1", ADMIN_TOKEN: ADMIN, PORT: "0" });
  const s = new Store(":memory:");
  const g = createServer(cfg, { store: s, limiter: new RateLimiter() });
  const url = await listen(g);
  const { key } = s.create({ email: "x@y.co", plan: "starter" });
  const r = await fetch(url + "/a", { headers: { authorization: `Bearer ${key}` } });
  assert.equal(r.status, 502);
  assert.equal((await r.json()).error.code, "upstream_unreachable");
  g.close();
});

test("multiple upstreams with prefix stripping", async () => {
  const other = http.createServer((req, res) => res.end(`other:${req.url}`));
  const otherUrl = await listen(other);
  const cfg = loadConfig({ ADMIN_TOKEN: ADMIN, PORT: "0" });
  cfg.routes = [
    { prefix: "/weather", target: otherUrl, strip: true },
    { prefix: "/", target: upstreamUrl, strip: false },
  ];
  const s = new Store(":memory:");
  const g = createServer(cfg, { store: s, limiter: new RateLimiter() });
  const url = await listen(g);
  const { key } = s.create({ email: "m@y.co", plan: "starter" });
  const h = { authorization: `Bearer ${key}` };
  assert.equal(await (await fetch(url + "/weather/today?c=uk", { headers: h })).text(), "other:/today?c=uk");
  assert.equal((await (await fetch(url + "/plain", { headers: h })).json()).path, "/plain");
  g.close();
  other.close();
});

test("CORS preflight is answered without a key", async () => {
  const r = await fetch(gwUrl + "/v1/x", { method: "OPTIONS" });
  assert.equal(r.status, 204);
  assert.ok(r.headers.get("access-control-allow-headers").includes("authorization"));
});

// ---------- admin API ----------

test("admin: rejects missing and wrong tokens", async () => {
  assert.equal((await fetch(gwUrl + "/_a888/api/keys")).status, 401);
  assert.equal((await admin("/keys", { token: "wrong-token-wrong-token" })).status, 401);
  assert.equal((await admin("/keys", { token: ADMIN })).status, 200);
});

test("admin: full key lifecycle over the API", async () => {
  const c = await admin("/keys", { method: "POST", body: { email: "life@example.com", plan: "pro", days: 10, paths: ["/v1/"], note: "hi" } });
  assert.equal(c.status, 201);
  const made = await c.json();
  assert.ok(looksLikeKey(made.key));
  assert.equal(made.plan, "pro");

  // The new key works through the gateway.
  assert.equal((await call("/v1/hello", { key: made.key })).status, 200);

  const list = await (await admin("/keys")).json();
  const row = list.keys.find((k) => k.id === made.id);
  assert.ok(row);
  assert.equal(row.used, 1);
  assert.equal(JSON.stringify(list).includes(made.key), false, "listing must never contain raw keys");

  assert.equal((await admin(`/keys/${made.id}/suspend`, { method: "POST" })).status, 200);
  assert.equal((await call("/v1/hello", { key: made.key })).status, 402);
  assert.equal((await admin(`/keys/${made.id}/resume`, { method: "POST" })).status, 200);
  assert.equal((await call("/v1/hello", { key: made.key })).status, 200);

  const renewed = await (await admin(`/keys/${made.id}/renew`, { method: "POST", body: { days: 30 } })).json();
  assert.ok(Date.parse(renewed.expires_at) > Date.parse(made.expires_at));

  assert.equal((await admin(`/keys/${made.id}/revoke`, { method: "POST" })).status, 200);
  assert.equal((await call("/v1/hello", { key: made.key })).status, 401);
  assert.equal((await admin(`/keys/${made.id}/resume`, { method: "POST" })).status, 400, "revoked keys cannot be restored");
});

test("admin: validates input", async () => {
  assert.equal((await admin("/keys", { method: "POST", body: { email: "nope", plan: "pro" } })).status, 400);
  assert.equal((await admin("/keys", { method: "POST", body: { email: "a@b.co", plan: "gold" } })).status, 400);
  assert.equal((await admin("/keys", { method: "POST", body: { email: "a@b.co", plan: "pro", paths: ["nosl"] } })).status, 400);
  assert.equal((await admin("/keys/deadbeefdead", { method: "GET" })).status, 404);
  assert.equal((await admin("/keys/abc", { method: "GET" })).status, 400, "id prefix too short");
});

test("admin: UI page is served with a strict CSP", async () => {
  const r = await fetch(gwUrl + "/_a888/");
  assert.equal(r.status, 200);
  assert.ok(r.headers.get("content-security-policy").includes("default-src 'none'"));
  assert.ok((await r.text()).includes("a888 admin"));
});

test("admin is disabled without a strong token", async () => {
  const cfg = loadConfig({ UPSTREAM: upstreamUrl, ADMIN_TOKEN: "short", PORT: "0" });
  const g = createServer(cfg, { store: new Store(":memory:"), limiter: new RateLimiter() });
  const url = await listen(g);
  assert.equal((await fetch(url + "/_a888/")).status, 404);
  assert.equal((await fetch(url + "/_a888/api/keys", { headers: { authorization: "Bearer short" } })).status, 404);
  g.close();
});

test("storage: raw keys are never persisted", () => {
  const { key } = newKey();
  const dump = JSON.stringify(store.db.prepare("SELECT * FROM keys").all());
  assert.equal(dump.includes(key), false);
});
